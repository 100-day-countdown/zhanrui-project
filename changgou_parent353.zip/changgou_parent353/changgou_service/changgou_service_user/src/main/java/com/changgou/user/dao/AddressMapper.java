package com.changgou.user.dao;

import com.changgou.user.pojo.Address;
import tk.mybatis.mapper.common.Mapper;

public interface AddressMapper extends Mapper<Address> {

}
