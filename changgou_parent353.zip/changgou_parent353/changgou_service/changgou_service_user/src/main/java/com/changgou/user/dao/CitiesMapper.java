package com.changgou.user.dao;

import com.changgou.user.pojo.Cities;
import tk.mybatis.mapper.common.Mapper;

public interface CitiesMapper extends Mapper<Cities> {

}
