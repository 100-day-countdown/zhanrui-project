package com.changgou.user.dao;

import com.changgou.user.pojo.Provinces;
import tk.mybatis.mapper.common.Mapper;

public interface ProvincesMapper extends Mapper<Provinces> {

}
