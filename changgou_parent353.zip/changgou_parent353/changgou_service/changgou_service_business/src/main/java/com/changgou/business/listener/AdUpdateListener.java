package com.changgou.business.listener;

import okhttp3.*;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * 监听rabbitmq, 大广告数据更新队列
 * 接收大广告的分类名称, 根据分类名称发送http请求到nginx服务器地址
 * nginx服务器接收到请求后, 就会去自动调用lua脚本, 从数据库中查询更新的广告数据, 存入redis分布式缓存中, 更新缓存广告内容
 * @author ZJ
 */
@Component
@RabbitListener(queues = "ad_update_queue")
public class AdUpdateListener {

    @RabbitHandler
    public void messageHandler(String message) {
        //1. 获取广告分类, 拼接成访问的nginx的url路径
        String url = "http://192.168.200.128/ad_update?position=" + message;
        //2. 创建okhttp请求对象
        OkHttpClient okHttpClient = new OkHttpClient();
        //3. 创建请求对象
        Request.Builder request = new Request.Builder().url(url);
        //4. 发送请求
        Call call = okHttpClient.newCall(request.build());
        //5. 接收回调, 才会知道发送请求成功还是失败
        call.enqueue(new Callback() {

            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println("====发送请求失败======");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                System.out.println("=====发送请求成功========" + response.message());
            }
        });
    }
}
