package com.changgou.file.controller;

import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.file.util.FastDFSClient;
import com.changgou.file.util.FastDFSFile;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * 文件管理
 * @author ZJ
 */
@RestController
@RequestMapping("/file")
public class FileController {

    /**
     * 上传文件
     *
     * multipartFile接口后的变量名要等于页面上传域的name属性名
     * <input type="file" name="file"/>
     */
    @RequestMapping("/upload")
    public Result upload(@RequestParam MultipartFile file) {
        try {
            //1. 获取上传文件的完整名称
            String originalFilename = file.getOriginalFilename();
            //2. 获取上传文件的扩展名
            if (StringUtils.isEmpty(originalFilename)) {
                return new Result(false, StatusCode.ERROR, "无法获取上传的文件名, 上传失败");
            }
            String ext = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);

            //3. 封装上传的文件实体对象
            FastDFSFile fastDFSFile = new FastDFSFile(originalFilename, file.getBytes(), ext);
            //4. 调用fastDFS工具类完成上传
            String[] path = FastDFSClient.upload(fastDFSFile);
            //5. 拼接存储后的文件的完整路径
            String trackerUrl = FastDFSClient.getTrackerUrl();
            String url = trackerUrl + path[0] + "/" + path[1];
            //6. 返回
            return new Result(true, StatusCode.OK, "上传成功", url);
        } catch (IOException e) {
            e.printStackTrace();
            return new Result(false, StatusCode.ERROR, "上传失败");
        }

    }
}
