package com.changgou.search.service;

import com.alibaba.fastjson.JSON;
import com.changgou.entity.Result;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.goods.pojo.Sku;
import com.changgou.search.dao.SkuInfoDao;
import com.changgou.search.pojo.SkuInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author ZJ
 */
@Service
public class EsManagerServiceImpl implements EsManagerService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private SkuFeign skuFeign;

    @Autowired
    private SkuInfoDao skuInfoDao;

    @Override
    public void createIndex() {
        //1. 创建索引库
        elasticsearchTemplate.createIndex(SkuInfo.class);
        //2. 创建映射结构
        elasticsearchTemplate.putMapping(SkuInfo.class);
    }

    @Override
    public void importAll() {
        //1. 将库存表所有数据查询出来
        Result<List<Sku>> result = skuFeign.findAll();
        List<Sku> skuList = result.getData();

        //2. 导入数据到es索引库
        //将库存集合转成json格式字符串
        String skuListJsonStr = JSON.toJSONString(skuList);
        //将库存json格式字符串转成skuinfo集合
        List<SkuInfo> skuInfos = JSON.parseArray(skuListJsonStr, SkuInfo.class);
        if (skuInfos != null) {
            for (SkuInfo skuInfo : skuInfos) {
                //获取规格json格式字符串
                String specJsonStr = skuInfo.getSpec();
                Map specMap = JSON.parseObject(specJsonStr, Map.class);
                skuInfo.setSpecMap(specMap);
            }
        }
        //保存数据到ES索引库中
        skuInfoDao.saveAll(skuInfos);
    }
}
