package com.changgou.search.service;

import com.alibaba.fastjson.JSON;
import com.changgou.search.pojo.SkuInfo;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.*;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.StringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.SearchResultMapper;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;
import org.springframework.data.elasticsearch.core.aggregation.impl.AggregatedPageImpl;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author ZJ
 */
@Service
public class SearchServiceImpl implements SearchService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    //每页显示20条数据
    public final static Integer PAGE_SIZE = 20;


    @Override
    public Map<String, Object> list(Map<String, String> searchMap) {
        if (searchMap == null) {
            return new HashMap<>();
        }
        /**
         * 1.从参数对象中获取查询参数, 并封装一些需要返回的结果对象
         */
        Map<String, Object> resultMap = new HashMap<>();
        //创建springDataES顶级查询对象
        NativeSearchQueryBuilder nativeSearchQueryBuilder = new NativeSearchQueryBuilder();
        //创建组合查询对象
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();


        //获取查询的关键字条件
        String keywords = searchMap.get("keywords");
        //获取品牌过滤条件
        String brand = searchMap.get("brand");
        //获取价格过滤条件
        String priceStr = searchMap.get("price");
        //获取排序的域
        String sortField = searchMap.get("sortField");
        //获取排序的方式
        String sortRule = searchMap.get("sortRule");
        //获取当前页
        String pageNumStr = searchMap.get("pageNum");

        /**
         * 2. 根据关键字查询
         */
        if (StringUtils.isEmpty(keywords)) {
            return new HashMap<>();
        }

        //模糊查询使用, 对查询的关键字进行切分词, 然后利用切分出来的词进行逐个查询, 再将分别查询出来的结果, 拼接在一起,
        //要求查询的字段必须是text类型
        MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("name", keywords).operator(Operator.AND);
        //如果有多个查询需求, 查询关系是并且的关系, 相当于And
        boolQueryBuilder.must(matchQueryBuilder);

        /**
         * 3. 按照品牌过滤查询
         */
        if (!StringUtils.isEmpty(brand)) {
            //精确查询, 不切分词
            TermQueryBuilder termQueryBuilder = QueryBuilders.termQuery("brandName", brand);
            //将品牌过滤查询对象放入组合查询中
            boolQueryBuilder.filter(termQueryBuilder);
        }

        /**
         * 4. 按照规格过滤查询
         */
        //遍历所有查询参数中的key
        for (String paramKey : searchMap.keySet()) {
            //找到key以spec_开头的, 这样的是规格参数
            if (paramKey.startsWith("spec_")) {
                //termQuery精确查询, 要求查询的域必须是keyword类型, 后面的.keyword是临时的类型转换
                TermQueryBuilder termQueryBuilder = QueryBuilders.termQuery("specMap." + paramKey.substring(5) + ".keyword", searchMap.get(paramKey));
                boolQueryBuilder.filter(termQueryBuilder);
            }
        }

        /**
         * 5. 按照价格范围过滤查询
         */
        if (!StringUtils.isEmpty(priceStr)) {
            //price[0]最小值, price[1]最大值
            String[] price = priceStr.split("-");
            if (!"0".equals(price[0])) {
                //大于等于最小值
                RangeQueryBuilder rangeQuery = QueryBuilders.rangeQuery("price").gte(price[0]);
                boolQueryBuilder.filter(rangeQuery);
            }
            if (!"*".equals(price[1])) {
                //小于等于最大值
                RangeQueryBuilder rangeQuery = QueryBuilders.rangeQuery("price").lte(price[1]);
                boolQueryBuilder.filter(rangeQuery);
            }
        }

        /**
         * 6. 排序
         */
        if (!StringUtils.isEmpty(sortField) && !StringUtils.isEmpty(sortRule)) {
            //升序
            if ("ASC".equals(sortRule)) {
                nativeSearchQueryBuilder.withSort(SortBuilders.fieldSort(sortField).order(SortOrder.ASC));
            }
            //降序
            if ("DESC".equals(sortRule)) {
                nativeSearchQueryBuilder.withSort(SortBuilders.fieldSort(sortField).order(SortOrder.DESC));
            }
        }

        /**
         * 7. 高亮查询
         */
        HighlightBuilder.Field highlightField = new HighlightBuilder.Field("name").preTags("<span style=\"color:red\">").postTags("</span>");
        nativeSearchQueryBuilder.withHighlightFields(highlightField);

        /**
         * 8. 分页查询
         */
        if (StringUtils.isEmpty(pageNumStr)) {
            pageNumStr = "1";
            searchMap.put("pageNum", pageNumStr);
        }
        int pageNum = Integer.parseInt(pageNumStr);
        if (pageNum <= 0) {
            pageNum = 1;
            searchMap.put("pageNum", "1");
        }
        //springDataES中当前页是从0开始计数.
        nativeSearchQueryBuilder.withPageable(PageRequest.of(pageNum - 1, PAGE_SIZE));

        /**
         * 9. 按照品牌聚合查询, 聚合查询的目的是去掉重复数据
         */
        //给当前的聚合查询起一个名称, 在获取聚合查询结果的时候使用
        String brandAgg = "brandAgg";
        TermsAggregationBuilder brandNameAgg = AggregationBuilders.terms(brandAgg).field("brandName");
        nativeSearchQueryBuilder.addAggregation(brandNameAgg);

        /**
         * 10. 按照规格聚合查询
         */
        String specAgg = "specAgg";
        TermsAggregationBuilder specNameAgg = AggregationBuilders.terms(specAgg).field("spec.keyword");
        nativeSearchQueryBuilder.addAggregation(specNameAgg);

        //在获取查询结果前, 将组合查询对象, 放入顶级查询对象中
        nativeSearchQueryBuilder.withQuery(boolQueryBuilder);
        /**
         * 11. 查询并返回查询到的结果集
         */
        AggregatedPage<SkuInfo> skuInfos = elasticsearchTemplate.queryForPage(nativeSearchQueryBuilder.build(), SkuInfo.class, new SearchResultMapper() {

            @Override
            public <T> AggregatedPage<T> mapResults(SearchResponse searchResponse, Class<T> aClass, Pageable pageable) {

                List<T> resultList = new ArrayList<>();
                //获取查询到的不带高亮名称的结果集
                SearchHits hits = searchResponse.getHits();
                if (hits != null) {
                    for (SearchHit hit : hits) {

                        //获取到一条json格式字符串数据
                        String sourceAsString = hit.getSourceAsString();
                        //将json转换成需要的对象
                        SkuInfo skuInfo = JSON.parseObject(sourceAsString, SkuInfo.class);


                        //单独获取高亮名称结果
                        Map<String, HighlightField> highlightFields = hit.getHighlightFields();
                        if (highlightFields != null && highlightFields.size() > 0) {
                            //获取高亮名称
                            String hightName = highlightFields.get("name").fragments()[0].toString();
                            //使用高亮名称覆盖skuInfo对象中不带高亮的名称
                            skuInfo.setName(hightName);
                        }


                        resultList.add((T)skuInfo);
                    }
                }
                //第一个参数: 查询到的结果集, 第二个参数: 分页对象, 第三个参数: 查询到的总记录数, 第四个参数: 聚合结果对象
                return new AggregatedPageImpl<T>(resultList, pageable, hits.totalHits, searchResponse.getAggregations());
            }
        });

        //获取查询到的结果集
        resultMap.put("rows", skuInfos.getContent());
        //获取查询到的总条数
        resultMap.put("total", skuInfos.getTotalElements());
        //获取查询到的总页数
        resultMap.put("totalPages", skuInfos.getTotalPages());
        //当前页
        resultMap.put("pageNum", pageNum);

        /**
         * 12. 获取品牌聚合结果集
         */
//        List<String> brandNameList = new ArrayList<>();
        StringTerms brandTerms = (StringTerms)skuInfos.getAggregation(brandAgg);
//        List<StringTerms.Bucket> buckets = brandTerms.getBuckets();
//        if (buckets != null) {
//            for (StringTerms.Bucket bucket : buckets) {
//                brandNameList.add(bucket.getKeyAsString());
//            }
//        }
        List<String> brandList = brandTerms.getBuckets().stream().map(bucket -> bucket.getKeyAsString()).collect(Collectors.toList());
        resultMap.put("brandList", brandList);

        /**
         * 13. 获取规格聚合结果集
         */
        StringTerms specTerms = (StringTerms)skuInfos.getAggregation(specAgg);
        List<String> specList = specTerms.getBuckets().stream().map(bucket -> bucket.getKeyAsString()).collect(Collectors.toList());
        resultMap.put("specList", mergeSpec(specList));
        return resultMap;
    }

    /**
     * 整理规格集合的格式, 并且要去重
     * @param specList  传入规格json格式字符串
     * 原数据例如:
     *       [
     *         "{'颜色': '蓝色', '版本': '6GB+128GB'}",
     *         "{'颜色': '黑色', '版本': '6GB+128GB'}",
     *         "{'颜色': '黑色', '版本': '4GB+64GB'}",
     *         "{'颜色': '蓝色', '版本': '4GB+64GB'}",
     *         "{'颜色': '蓝色', '版本': '6GB+64GB'}",
     *         "{'颜色': '蓝色'}",
     *         "{'颜色': '金色', '版本': '4GB+64GB'}",
     *         "{'颜色': '粉色', '版本': '6GB+128GB'}"
     *     ]
     *
     * 返回的数据格式例如:
     *     {
     *       "颜色" : ["蓝色","黑色", "金色", "粉色"],
     *       "版本" : ["6GB+128GB","4GB+64GB","6GB+64GB"]
     *     }
     *
     */
    public Map<String, Set<String>> mergeSpec(List<String> specList) {
        Map<String, Set<String>> resultMap = new HashMap<>();
        if (specList != null) {
            //数据例如: {'颜色': '蓝色', '版本': '6GB+128GB'}"
            for (String specJsonStr : specList) {
                Map<String, String> specMap = JSON.parseObject(specJsonStr, Map.class);
                //specMapKey的值例如: 颜色, 版本
                for (String specMapKey : specMap.keySet()) {
                    Set<String> specSet = resultMap.get(specMapKey);
                    if(specSet == null) {
                        specSet = new HashSet<>();
                    }
                    //向set集合中加入值, set有自动去重的效果
                    specSet.add(specMap.get(specMapKey));
                    //向resultMap中从新加入set集合, 覆盖以前的值
                    resultMap.put(specMapKey, specSet);
                }
            }
        }
        return resultMap;
    }
}
