package com.changgou.search.service;

import java.util.Map;

/**
 * @author ZJ
 */
public interface SearchService {

    public Map<String, Object> list(Map<String, String> searchMap);
}
