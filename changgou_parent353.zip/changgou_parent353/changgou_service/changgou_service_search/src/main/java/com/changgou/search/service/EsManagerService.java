package com.changgou.search.service;

/**
 * @author ZJ
 */
public interface EsManagerService {

    /**
     * 创建索引库和映射结构
     */
    public void createIndex();

    /**
     * 导入sku库存全部数据到es索引库中
     */
    public void importAll();
}
