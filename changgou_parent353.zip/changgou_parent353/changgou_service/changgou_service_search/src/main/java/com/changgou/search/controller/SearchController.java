package com.changgou.search.controller;

import com.changgou.entity.Page;
import com.changgou.search.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 搜索
 * @author ZJ
 */
@Controller
@RequestMapping("/search")
public class SearchController {

    @Autowired
    private SearchService searchService;

    /**
     * 在接收参数的时候处理参数中规格的乱码问题
     * @param searchMap
     * @return
     */
    private Map<String, String> paramHandler(Map<String, String> searchMap) {
        if (searchMap != null) {
            for (String paramKey : searchMap.keySet()) {
                //找到key以spec_开头的, 这样的是规格参数
                if (paramKey.startsWith("spec_")) {
                    //处理规格中加号乱码问题
                    String value = searchMap.get(paramKey).replace(" ", "+");
                    searchMap.put(paramKey, value);
                }
            }
        }
        return searchMap;
    }

    /**
     * 搜索
     * @param searchMap 查询条件对象
     * @return
     */
    @GetMapping("/list")
    public String list(@RequestParam Map<String, String> searchMap, Model model) {
        searchMap = paramHandler(searchMap);
        Map<String, Object> resultMap = searchService.list(searchMap);
        //查询结果数据
        model.addAttribute("result", resultMap);
        //查询参数数据
        model.addAttribute("searchMap", searchMap);

        //返回分页对象数据, 第一个参数: 查询到的中记录数, 第二个参数: 当前页, 第三个参数: 每页展示数据条数
        Page page = new Page(Long.parseLong(String.valueOf(resultMap.get("total"))),
                Integer.parseInt(String.valueOf(resultMap.get("pageNum"))),
                Page.pageSize
                );
        model.addAttribute("page", page);

        //拼接url地址所携带参数
        StringBuffer url = new StringBuffer("/search/list");
        //遍历传入的查询参数
        if (searchMap != null && searchMap.size() > 0) {
            url.append("?");
            int flag = 0;
            for (String searchMapKey : searchMap.keySet()) {
                //如果是当前页, 排序字段, 排序方式不需要拼接到url参数中
                if (!"pageNum".equals(searchMapKey)
                        && !"sortField".equals(searchMapKey)
                        && !"sortRule".equals(searchMapKey)) {
                    if (flag != 0) {
                        url.append("&");
                    }
                    url.append(searchMapKey).append("=").append(searchMap.get(searchMapKey));
                    flag++;
                }
            }
        }
        model.addAttribute("url", url.toString());


        return "search";
    }
}
