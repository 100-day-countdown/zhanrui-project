package com.changgou.search.listener;

import com.alibaba.fastjson.JSON;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.goods.pojo.Sku;
import com.changgou.search.dao.SkuInfoDao;
import com.changgou.search.pojo.SkuInfo;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 业务:
 *      监听索引库上架队列, 接收需要上架的商品id
 *      根据商品id, 查询对应的库存集合数据, 存入ES索引库中, 供消费者搜索使用
 * @author ZJ
 */
@Component
@RabbitListener(queues = "search_add_queue")
public class SkuToESListener {

    @Autowired
    private SkuFeign skuFeign;

    @Autowired
    private SkuInfoDao skuInfoDao;

    @RabbitHandler
    public void messageHandler(String spuId) {
        //1. 根据商品id, 查询对应的库存集合数据
        List<Sku> skuList = skuFeign.findListBySpuId(spuId);

        //2. 将库存集合数据导入到es索引库中
        //将库存集合转成json格式字符串
        String skuListJsonStr = JSON.toJSONString(skuList);
        //将库存json格式字符串转成skuinfo集合
        List<SkuInfo> skuInfos = JSON.parseArray(skuListJsonStr, SkuInfo.class);
        if (skuInfos != null) {
            for (SkuInfo skuInfo : skuInfos) {
                //获取规格json格式字符串
                String specJsonStr = skuInfo.getSpec();
                Map specMap = JSON.parseObject(specJsonStr, Map.class);
                skuInfo.setSpecMap(specMap);
            }
        }
        //保存数据到ES索引库中
        skuInfoDao.saveAll(skuInfos);
    }
}
