package com.changgou.test;

import org.springframework.security.crypto.bcrypt.BCrypt;

/**
 * @author ZJ
 */
public class TestBcrypt {

    public static void main(String[] args) {
        //获取盐值
        String gensalt = BCrypt.gensalt();
        //加密
        String hashpw = BCrypt.hashpw("123456", gensalt);
        System.out.println("=======" + hashpw);

        String  aaa = "$2a$10$Cfe/2Nr1q.FSNyW327AdD.NTklhEU5nl3sfYIR1iTxGaOAbdlo.W2";
        boolean checkpw = BCrypt.checkpw("123456", aaa);
        System.out.println("=====" + checkpw);
    }
}
