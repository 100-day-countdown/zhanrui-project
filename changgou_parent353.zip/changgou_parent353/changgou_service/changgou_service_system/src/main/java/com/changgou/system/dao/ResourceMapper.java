package com.changgou.system.dao;

import com.changgou.system.pojo.Resource;
import tk.mybatis.mapper.common.Mapper;

public interface ResourceMapper extends Mapper<Resource> {

}
