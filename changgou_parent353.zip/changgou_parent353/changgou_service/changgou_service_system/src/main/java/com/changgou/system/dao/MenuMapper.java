package com.changgou.system.dao;

import com.changgou.system.pojo.Menu;
import tk.mybatis.mapper.common.Mapper;

public interface MenuMapper extends Mapper<Menu> {

}
