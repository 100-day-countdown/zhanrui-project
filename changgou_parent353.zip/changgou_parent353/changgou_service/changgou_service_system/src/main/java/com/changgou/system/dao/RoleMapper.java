package com.changgou.system.dao;

import com.changgou.system.pojo.Role;
import tk.mybatis.mapper.common.Mapper;

public interface RoleMapper extends Mapper<Role> {

}
