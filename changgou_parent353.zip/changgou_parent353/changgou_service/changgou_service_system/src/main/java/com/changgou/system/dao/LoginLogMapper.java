package com.changgou.system.dao;

import com.changgou.system.pojo.LoginLog;
import tk.mybatis.mapper.common.Mapper;

public interface LoginLogMapper extends Mapper<LoginLog> {

}
