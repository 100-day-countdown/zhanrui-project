package com.changgou.system.dao;

import com.changgou.system.pojo.Admin;
import tk.mybatis.mapper.common.Mapper;

public interface AdminMapper extends Mapper<Admin> {

}
