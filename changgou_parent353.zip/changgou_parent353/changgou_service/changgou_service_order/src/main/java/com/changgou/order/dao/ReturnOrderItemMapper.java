package com.changgou.order.dao;

import com.changgou.order.pojo.ReturnOrderItem;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnOrderItemMapper extends Mapper<ReturnOrderItem> {

}
