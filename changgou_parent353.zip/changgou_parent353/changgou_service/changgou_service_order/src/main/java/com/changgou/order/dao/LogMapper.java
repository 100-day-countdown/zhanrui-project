package com.changgou.order.dao;

import com.changgou.order.pojo.Log;
import tk.mybatis.mapper.common.Mapper;

public interface LogMapper extends Mapper<Log> {

}
