package com.changgou.order.dao;

import com.changgou.order.pojo.OrderItem;
import tk.mybatis.mapper.common.Mapper;

public interface OrderItemMapper extends Mapper<OrderItem> {

}
