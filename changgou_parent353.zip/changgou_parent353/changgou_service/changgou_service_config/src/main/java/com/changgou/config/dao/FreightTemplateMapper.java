package com.changgou.config.dao;

import com.changgou.config.pojo.FreightTemplate;
import tk.mybatis.mapper.common.Mapper;

public interface FreightTemplateMapper extends Mapper<FreightTemplate> {

}
