package com.changgou.page.service;

import java.util.Map;

/**
 * @author ZJ
 */
public interface PageService {

    /**
     * 根据商品id, 获取商品, 库存集合, 图片, 规格, 分类等数据
     * @param spuId
     * @return
     */
    public Map<String, Object> findDataBySpuId(String spuId);


    /**
     * 生成商品详情页面
     * @param dataMap   生成页面需要的数据
     * @param spuId     商品id, 作为详情页面文件名
     */
    public void createPage(Map<String, Object> dataMap, String spuId);
}
