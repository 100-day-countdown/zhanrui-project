package com.changgou.page.service;

import com.alibaba.fastjson.JSON;
import com.changgou.goods.feign.CategoryFeign;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.goods.feign.SpuFeign;
import com.changgou.goods.pojo.Category;
import com.changgou.goods.pojo.Sku;
import com.changgou.goods.pojo.Spu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ZJ
 */
@Service
public class PageServiceImpl implements PageService {

    @Autowired
    private SpuFeign spuFeign;

    @Autowired
    private SkuFeign skuFeign;

    @Autowired
    private CategoryFeign categoryFeign;

    @Autowired
    private TemplateEngine templateEngine;

    //静态页生成的路径
    @Value("${pagepath}")
    private String pagepath;


    @Override
    public Map<String, Object> findDataBySpuId(String spuId) {
        Map<String, Object> resultMap = new HashMap<>();

        //1. 根据商品id, 获取商品对象
        Spu spu = spuFeign.findById(spuId);
        resultMap.put("spu", spu);

        //2. 根据商品id, 获取库存集合对象
        List<Sku> skuList = skuFeign.findListBySpuId(spuId);
        resultMap.put("skuList", skuList);

        if (spu != null) {
            //3. 获取分类对象
            Category category1 = categoryFeign.findById(spu.getCategory1Id());
            Category category2 = categoryFeign.findById(spu.getCategory2Id());
            Category category3 = categoryFeign.findById(spu.getCategory3Id());
            resultMap.put("category1", category1);
            resultMap.put("category2", category2);
            resultMap.put("category3", category3);

            //4. 获取图片对象
            String imagesJSONStr = spu.getImages();
            List<String> imageList = new ArrayList<>();
            List<Map> maps = JSON.parseArray(imagesJSONStr, Map.class);
            if (maps != null) {
                for (Map map : maps) {
                    imageList.add(String.valueOf(map.get("url")));
                }
            }
            resultMap.put("imageList", imageList);

            //5. 获取规格对象
            String specItemsJsonStr = spu.getSpecItems();
            Map specMap = JSON.parseObject(specItemsJsonStr, Map.class);
            resultMap.put("specificationList", specMap);

        }

        return resultMap;
    }

    @Override
    public void createPage(Map<String, Object> dataMap, String spuId) {
        //1. 创建thymeleaf模板引擎存放数据的对象, 将数据放入进去
        Context context = new Context();
        context.setVariables(dataMap);

        //2. 获取静态页生成的目标路径
        String path = pagepath + "/" + spuId +  ".html";

        //3. 判断路径中的文件夹是否存在,
        File dir = new File(pagepath);
        if (!dir.exists()) {
            //如果不存在则自动创建需要的文件夹
            dir.mkdirs();
        }


        Writer writer = null;
        try {
            //4. 创建输出流对象, 指定文件生成的位置和文件名
            writer = new PrintWriter(new File(path));
            //5. 生成
            //第一个参数: 模板名称, 第二个参数: 模板需要的数据对象, 第三个参数: 输出流, 指定输出位置和文件名
            templateEngine.process("item", context, writer);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                //6. 关闭资源
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
