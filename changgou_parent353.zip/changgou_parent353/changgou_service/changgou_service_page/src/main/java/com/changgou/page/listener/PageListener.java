package com.changgou.page.listener;

import com.changgou.page.service.PageService;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 监听静态页生成队列
 * 获取商品id, 根据商品id, 查询到商品对象, 库存集合对象, 分类对象, 图片数据, 规格数据等
 * 然后根据模板生成商品详情页面, 供消费者访问使用
 * @author ZJ
 */
@Component
@RabbitListener(queues = "page_create_queue")
public class PageListener {

    @Autowired
    private PageService pageService;

    @RabbitHandler
    public void messageHandler(String spuId) {
        System.out.println("===========生成商品详情页面==============spuId===" + spuId);
        //1. 根据商品id获取模板中需要的数据
        Map<String, Object> dataMap = pageService.findDataBySpuId(spuId);

        //2. 使用模板和数据生成商品详情页面
        pageService.createPage(dataMap, spuId);

    }
}
