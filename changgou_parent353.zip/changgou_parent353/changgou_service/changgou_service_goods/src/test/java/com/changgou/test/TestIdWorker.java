package com.changgou.test;

import com.changgou.util.IdWorker;

/**
 * @author ZJ
 */
public class TestIdWorker {

    public static void main(String[] args) {
        IdWorker idWorker = new IdWorker(1, 1);
        for (int i =1 ; i <= 10000; i++) {
            System.out.println("======" + idWorker.nextId());
        }
    }
}
