package com.changgou.goods.dao;

import com.changgou.goods.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

public interface SkuMapper extends Mapper<Sku> {

}
