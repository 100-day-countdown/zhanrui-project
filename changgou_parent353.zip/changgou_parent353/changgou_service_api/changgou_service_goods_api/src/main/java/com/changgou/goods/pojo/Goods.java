package com.changgou.goods.pojo;

import java.io.Serializable;
import java.util.List;

/**
 * 商品实体类
 *      包含商品spu对象, 和库存集合对象sku
 * @author ZJ
 */
public class Goods implements Serializable {

    private Spu spu;

    private List<Sku> skuList;

    public Spu getSpu() {
        return spu;
    }

    public void setSpu(Spu spu) {
        this.spu = spu;
    }

    public List<Sku> getSkuList() {
        return skuList;
    }

    public void setSkuList(List<Sku> skuList) {
        this.skuList = skuList;
    }
}
