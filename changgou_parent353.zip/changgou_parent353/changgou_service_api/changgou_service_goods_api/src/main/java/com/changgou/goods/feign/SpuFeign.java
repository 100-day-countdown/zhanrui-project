package com.changgou.goods.feign;

import com.changgou.goods.pojo.Spu;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author ZJ
 */
@FeignClient(name = "goods")
public interface SpuFeign {

    /***
     * 根据ID查询数据
     * @param id
     * @return
     */
    @GetMapping("/spu/{id}")
    public Spu findById(@PathVariable String id);
}
