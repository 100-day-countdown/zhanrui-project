package com.changgou.goods.feign;

import com.changgou.entity.Result;
import com.changgou.goods.pojo.Sku;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * @author ZJ
 */
@FeignClient(name = "goods")
public interface SkuFeign {

    /**
     * 根据商品id查询库存集合
     * @param spuId
     */
    @GetMapping("/sku/spu/{spuId}")
    public List<Sku> findListBySpuId(@PathVariable("spuId") String spuId);

    /**
     * 查询全部数据
     * @return
     */
    @GetMapping("/sku")
    public Result<List<Sku>> findAll();
}
