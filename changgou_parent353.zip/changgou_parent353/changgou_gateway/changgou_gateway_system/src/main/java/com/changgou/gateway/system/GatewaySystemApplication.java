package com.changgou.gateway.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.filter.ratelimit.KeyResolver;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * @author ZJ
 */
@SpringBootApplication
@EnableEurekaClient
public class GatewaySystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewaySystemApplication.class, args);
    }

    /**
     * 获取访问者的ip地址, 交给spring进行管理
     * @return
     */
    @Bean
    public KeyResolver ipKeyResolver() {
        return new KeyResolver() {
            @Override
            public Mono<String> resolve(ServerWebExchange exchange) {
                //从请求中获取访问者的ip地址返回
                return Mono.just(exchange.getRequest().getRemoteAddress().getHostName());
            }
        };

    }
}
