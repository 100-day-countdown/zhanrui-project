package com.changgou.test;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

/**
 * jwt解析
 * @author ZJ
 */
public class TestJwtParse {

    public static void main(String[] args) {
        //生成的jwt字符串
        String jwtStr = "eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIwNjVmM2QwOC0zNjIxLTQ4ODAtYjUyYy0zN2JkNjk4ZmJjYzIiLCJzdWIiOiLnrqHnkIblkZgiLCJpc3MiOiJ6aGFuZ3NhbiIsImlhdCI6MTU3MTM4OTQzMCwiZXhwIjoxNTcxMzk5NDI5LCJwZXJtaXNpb24iOiJhZG1pbixzeXN0ZW0seHh4In0.e0p3MMG9BKIuRTjnkG4KRtU5ZPAS07FCmBWdbtYJHT0";
        //解析jwt字符串
        Jws<Claims> jwts = Jwts.parser().setSigningKey("itcast").parseClaimsJws(jwtStr);

        System.out.println("=====" + jwts.getBody());
    }
}
