package com.changgou.test;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.UUID;

/**
 * jwt创建
 * @author ZJ
 */
public class TestJwtCreate {

    public static void main(String[] args) {

        long currentTimeMillis = System.currentTimeMillis();
        Date date = new Date(currentTimeMillis + 10000000);

        JwtBuilder jwtBuilder = Jwts.builder()
                .setId(UUID.randomUUID().toString())//jwt唯一标识
                .setSubject("管理员")//主题
                .setIssuer("zhangsan")//jwt的创建者
                .setIssuedAt(new Date()) //jwt创建时间
                .setExpiration(date)//超时时间
                .claim("permision","admin,system,xxx")//设置自定义信息
                //指定签名所使用的加密算法, 和秘钥
                .signWith(SignatureAlgorithm.HS256, "itcast");

        System.out.println("====" + jwtBuilder.compact());
    }
}
